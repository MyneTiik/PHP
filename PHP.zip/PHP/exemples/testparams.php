<!-- Cette page php lit une valeur passée en paramètre de l'URL
dans le navigateur sur ce modèle :
http://localhost/testparams.php?nom=MASCARON&prenom=Stéphane
-->
<!DOCTYPE html>
<html>

<head>
    <title>Lecture des paramètres dans l'URL</title>
    <link href="styles.css" rel="stylesheet">
</head>
<body>
    <p>Bonjour  M <?php echo $_GET['nom'] ?> <?php echo $_GET['prenom'] ?> !</p>
</body>
</html>
