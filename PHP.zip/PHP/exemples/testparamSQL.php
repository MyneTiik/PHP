<!-- Page PHP qui utilise un paramètre passé dans l'URL qui permet
de créer un filtre sur une  requête SQL avec une clause "where".
On appelle cette page avec l'URL suivante : 
http://localhost/testparamSQL.php?salle=showroom
-->
<!DOCTYPE html>
<html>
<head>
    <title>Lecture des paramètres pour filtre d'une requête SQL</title>
    <link href="styles.css" rel="stylesheet">
</head>

<body>
    <!-- Connexion à la base de données SQLite -->
    <?php
        $db = new SQLite3('tp2_M2104.sqlite3');
    ?>
    <p>liste des enregistrements de machines dont la salle est passée en paramètre de l'URL</p>
    <!-- préparation de la requête et exécution de celle-ci pour affichage dans un tableau -->
    <?php
        $requete = "SELECT * FROM machine where salle='".($_GET["salle"]."'");
        echo $requete;
        $results = $db->query($requete);
    ?>  
    <table>
        <thead>
            <tr>
                <th>N°</th>
                <th>Nom PC</th>
                <th>Date Achat</th>
                <th>Salle</th>
            </tr>
        </thead>
        <!-- Affichage des données de la requête dans un tableau HTML -->
        <?php
        while ($row = $results->fetchArray()) {
            echo "<tr>
                    <td>{$row['numpc']}</td>
                    <td>{$row['nompc']}</td>
                    <td>{$row['dateachat']}</td>
                    <td>{$row['salle']}</td>
                 </tr>";
        }
        ?>
    </table>
</body>

</html>