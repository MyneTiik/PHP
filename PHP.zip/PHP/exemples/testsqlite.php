<!-- Cette page fait une connexion à la bas de données SQLite
et affiche les données contenues dans les tables -->
<!DOCTYPE html>
<html>

<head>
    <title>Connexion SQLite et SELECT</title>
    <link href="styles.css" rel="stylesheet">
</head>

<body>
    <?php
    $db = new SQLite3('tp2_M2104.sqlite3');
    $results = $db->query('SELECT * FROM machine');
    ?>
    <h3> Table des machines</h3>
    <table>
        <thead>
            <tr>
                <th>N°</th>
                <th>Nom PC</th>
                <th>Date Achat</th>
                <th>Salle</th>
            </tr>
        </thead>

        <?php
        while ($row = $results->fetchArray()) {
            echo "<tr>
                    <td>{$row['numpc']}</td>
                    <td>{$row['nompc']}</td>
                    <td>{$row['dateachat']}</td>
                    <td>{$row['salle']}</td>
                 </tr>";
        }
        ?>
    </table>
    <hr>
    <h3>Exemple liste déroulante des composants</h3>
    <select name="composant">
        <?php
        $results = $db->query('SELECT * FROM composant');
        while ($row = $results->fetchArray()) {
            echo "<option value=\"{$row['refcomp']}\">{$row['nomcomp']}-{$row['marque']}-{$row['type']}</option>";
        }
        ?>
    </select>
    <hr>
    <h3> Liste de la table Assemble en liste à puces</h3>
    <ul>
        <?php
        $results = $db->query('SELECT * FROM assemble');
        while ($row = $results->fetchArray()) {
            echo "<li>{$row['numpc']}-{$row['refcomp']}-{$row['qte']}</li>";
        }
        ?>
    </ul>
</body>
</html>