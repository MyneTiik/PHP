<?php include 'head.php'; ?>
<?php include 'nav.php'; ?>

<div class="container">
    <h1>Merci pour votre commande !</h1>
    <p>Nous vous remercions pour votre achat. Vous recevrez votre votre commande d'ici 15 jours.</p>
    <p>N'h&eacutesitez pas &agrave; laisser un commentaire !<p>
    <a href="commentaire.php" class="btn btn-primary">Laissez un commentaire</a>
    <p>Si vous avez des questions, n'h&eacutesitez pas &agrave; nous contacter.</p>
    <a href="index.php" class="btn btn-primary">Retour &agrave; l'accueil</a>
</div>

<?php
// Empty the shopping cart
$_SESSION['panier_id'] = array();
$_SESSION['panier_equipe'] = array();


?>

<?php include 'footer.php'; ?>