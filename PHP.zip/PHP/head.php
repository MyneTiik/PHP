<head>
        <link rel='stylesheet' href='css/style.css'>
        <title>Footix.com</title>
        <meta charset='UTF-8'>
        <link rel="icon" type="image/x-icon" href="icone.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<h1 style="text-align: center;"> FOOTIX </h1>

<?php session_start(); ?>