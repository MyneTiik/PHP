<?php include 'head.php'; ?>
<?php include 'nav.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <h1>Footix.com</h1>
                <p>Bienvenue sur Footix.com !

Fans de foot, vous &ecirc;tes au bon endroit ! Sur Footix, trouvez les maillots de vos &eacute;quipes pr&eacute;f&eacute;r&eacute;es et portez fi&egrave;rement leurs couleurs. Clubs de l&eacute;gende ou s&eacute;lections nationales, nous avons ce qu'il vous faut !

Explorez notre collection de produits authentiques et profitez de nos super promos. Besoin d'aide ? Notre &eacute;quipe est l&agrave; pour vous !

Merci de choisir Footix.com. Ensemble, vivons notre passion du football !

Allez Footix, et vive le foot !</p>
            </div>
        </div>
    </div>
</div>

<hr size="10px">

<?php
$db = new SQLite3('basefoot.sqlite');
// Assuming you have a database connection established

// Fetch comments from the database
$query = "SELECT * FROM commentaire";
$result = $db->query($query);

// Display comments
while ($row = $result->fetchArray()) {
    $pseudo = $row['pseudo'];
    $commentaire = $row['comm'];

    echo "<div class='row '>
        <div class='col ml-1'>
            <div class='text-left p-3'>
                <h3>$pseudo</h3>
                <div class='border'>
                    <p>$commentaire</p>
                </div>
            </div>
        </div>
    </div>";
}
?>


<?php include 'footer.php'; ?>