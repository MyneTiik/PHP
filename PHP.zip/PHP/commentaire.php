<?php
include 'head.php';
include 'nav.php';
?>


<?php

$db = new SQLite3('basefoot.sqlite');

$pseudo = $_SESSION['pseudo'];
$commentaire = $_POST['coms_txt'];

if (!empty($pseudo) && !empty($commentaire)) {
	$requete = 'INSERT INTO commentaire (pseudo, comm) values (:pseudo, :commentaire)';
	$result = $db->prepare($requete);
	$result->bindValue(':pseudo', $pseudo);
	$result->bindValue(':commentaire', $commentaire);

	$result->execute();
    echo "Votre commentaire est pris en compte. Pseudo: " . $pseudo;

    header('Location: index.php');


}
?>

<div class="container">
    <h2>Laisser votre commentaire :</h2>
    <form method="POST" action="commentaire.php">
        <input type="text" style="width: 1000px; font-size: 15px; padding: 7px;" name="coms_txt" value="" />
        <button type="submit" class="btn btn-primary">Envoyer votre commentaire</button>
    </form>
</div>
<br>

<?php include 'footer.php'; ?>

